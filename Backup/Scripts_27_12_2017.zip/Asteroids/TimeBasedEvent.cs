﻿namespace Asteroids
{
    public abstract class TimeBasedEvent
    {
        public readonly double InvokationTime;

        public TimeBasedEvent(double invokationTime)
        {
            InvokationTime = invokationTime;
        }

        public abstract void Invoke();
    }
}