﻿using System.Collections.Generic;

namespace Asteroids
{
    public class TimeBasedEventQueue<T> where T : TimeBasedEvent
    {
        private LinkedList<T> _events = new LinkedList<T>();

        public void HandleEvents(double currentTime)
        {
            var eveContainer = _events.First;
            while(eveContainer != null)
            {
                var eve = eveContainer.Value;
                if (eve.InvokationTime > currentTime) return;
                eve.Invoke();
                _events.RemoveFirst();
                eveContainer = _events.First;
            }
        }

        public void AddEvent(T eventObj)
        {
            var eventTime = eventObj.InvokationTime;
            var last = _events.FindFirst(x => x.InvokationTime > eventTime);
            var eveContainer = new LinkedListNode<T>(eventObj);
            if (last == null) _events.AddLast(eveContainer);
            else _events.AddBefore(last, eveContainer);
        }

        public void RemoveEvent(T eventObj)
        {
            _events.Remove(eventObj);
        }
    }
}