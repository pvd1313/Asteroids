﻿using UnityEngine.Assertions;

namespace Asteroids
{
    [System.Serializable]
    public struct MinMax
    {
        public double Min;
        public double Max;

        public MinMax(double min, double max)
        {
            Assert.IsTrue(min <= max);
            Min = min;
            Max = max;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is MinMax)) return false;
            var minMax = (MinMax)obj;
            return this == minMax;
        }

        public override int GetHashCode()
        {
            return (int)(Min / Max) + (int)(Min * Max);
        }

        public double Lerp(double delta)
        {
            return Min + (Max - Min) * delta;
        }

        public static bool operator==(MinMax left, MinMax right)
        {
            return left.Min == right.Min && left.Max == right.Max;
        }

        public static bool operator!=(MinMax left, MinMax right)
        {
            return left.Min != right.Min || left.Max != right.Max;
        }
    }
}