﻿using System;
using UnityEngine;

namespace Asteroids
{
    [Serializable]
    public struct PlanarVector
    {
        public static readonly PlanarVector Zero = new PlanarVector(0, 0);

        public double X;
        public double Y;

        public PlanarVector(double x, double y)
        {
            X = x;
            Y = y;
        }

        public double Magnitude
        {
            get { return Math.Sqrt(X * X + Y * Y); } 
        }

        public double SqrMagnitude
        {
            get { return X * X + Y * Y; }
        }

        public static double Distance(PlanarVector pointA, PlanarVector pointB)
        {
            var dX = pointA.X - pointB.X;
            var dY = pointA.Y - pointB.Y;
            return Math.Sqrt(dX * dX + dY * dY);
        }

        public static double SqrDistance(PlanarVector pointA, PlanarVector pointB)
        {
            var dX = pointA.X - pointB.X;
            var dY = pointA.Y - pointB.Y;
            return dX * dX + dY * dY;
        }

        public PlanarVector Normalized
        {
            get { return this / Magnitude; }
        }

        public static explicit operator PlanarVector(Vector3 source)
        {
            return new PlanarVector(source.x, source.z);
        }

        public static explicit operator Vector3(PlanarVector source)
        {
            return new Vector3((float)source.X, 0, (float)source.Y);
        }

        public static PlanarVector operator /(PlanarVector vector, double value)
        {
            return new PlanarVector(vector.X / value, vector.Y / value);
        }

        public static PlanarVector operator *(PlanarVector vector, double value)
        {
            return new PlanarVector(vector.X * value, vector.Y * value);
        }

        public static PlanarVector operator +(PlanarVector a, PlanarVector b)
        {
            return new PlanarVector(a.X + b.X, a.Y + b.Y);
        }

        public static PlanarVector operator -(PlanarVector a, PlanarVector b)
        {
            return new PlanarVector(a.X - b.X, a.Y - b.Y);
        }

        public override string ToString ()
		{
			return string.Format ("{0}, {1}", X, Y);
		}
    }
}