﻿using System;

namespace Asteroids
{
    public struct PlanarRotation
    {
        private readonly double _sin;
        private readonly double _cos;

        public static PlanarVector RotateXAxis(double xComponent, double angle)
        {
            return new PlanarVector(xComponent * Math.Cos(angle), xComponent * Math.Sin(angle));
        }

        public PlanarRotation(double angle)
        {
            _cos = Math.Cos(angle);
            _sin = Math.Sin(angle);
        }

        public PlanarVector Rotate(PlanarVector source)
        {
            return new PlanarVector(source.X * _cos - source.Y * _sin, source.X * _sin + source.Y * _cos);
        }

        public PlanarVector RotateXAxis(double xComponent)
        {
            return new PlanarVector(xComponent * _cos, xComponent * _sin);
        }

        public PlanarVector InvertedRotate(PlanarVector source)
        {
            return new PlanarVector(source.X * _cos + source.Y * _sin, source.Y * _cos - source.X * _sin);
        }
    }
}