﻿using System;

namespace Asteroids
{
    public partial class MathUtil
    {
        public const double TWO_PI = 2 * Math.PI;
        public const double Deg2Rad = 1.0 / 180 * Math.PI;
        public const double Rad2Deg = 1.0 / Math.PI * 180;

        public static double Acosh(double cosh)
        {
            return Math.Log(cosh + Math.Sqrt(cosh + 1) * Math.Sqrt(cosh - 1));
        }

        public static double Atanh(double tanh)
        {
            return Math.Log((1 + tanh) / (1 - tanh)) / 2;
        }

        public static double Repeat(double t, double length)
        {
            return t - Math.Floor(t / length) * length;
        }

        public static double RepeatAngle(double angle)
        {
            return angle - Math.Floor(angle / TWO_PI) * TWO_PI;
        }

        public static double CreateClockwiseRotationAngle(double startAngle, double endAngle)
        {
            startAngle = RepeatAngle(startAngle);
            endAngle = RepeatAngle(endAngle);
            if (endAngle > startAngle) return endAngle - startAngle;
            else return TWO_PI - startAngle + endAngle;
        }

        public static double CreateCounterclockwiseRotationAngle(double startAngle, double endAngle)
        {
            startAngle = RepeatAngle(startAngle);
            endAngle = RepeatAngle(endAngle);
            if (startAngle > endAngle) return endAngle - startAngle;
            else return endAngle - startAngle - TWO_PI;
        }
    }
}
