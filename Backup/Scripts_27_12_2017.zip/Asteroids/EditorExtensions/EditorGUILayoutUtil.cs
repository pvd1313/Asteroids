﻿using UnityEditor;

namespace Asteroids.EditorExtensions
{
    public static class EditorGUILayoutUtil
    {
        public static void HorizontalDisabledTextFields(params string[] fields)
        {
            BeginHorizontal(true);
            foreach (var field in fields)
                EditorGUILayout.TextField(field);
            EndHorizontal();
        }

        public static void HorizontalDelayedDoubleFields(bool canEdit, ref double field0, ref double field1)
        {
            BeginHorizontal(!canEdit);
            field0 = EditorGUILayout.DelayedDoubleField(field0);
            field1 = EditorGUILayout.DelayedDoubleField(field1);
            EndHorizontal();
        }

        public static void HorizontalDelayedDoubleFields(bool canEdit, ref double field0, ref double field1, ref double field2)
        {
            BeginHorizontal(!canEdit);
            field0 = EditorGUILayout.DelayedDoubleField(field0);
            field1 = EditorGUILayout.DelayedDoubleField(field1);
            field2 = EditorGUILayout.DelayedDoubleField(field2);
            EndHorizontal();
        }

        private static void BeginHorizontal(bool disabled)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUI.BeginDisabledGroup(disabled);
        }

        private static void EndHorizontal()
        {
            EditorGUILayout.EndHorizontal();
            EditorGUI.EndDisabledGroup();
        }
    }
}