﻿using UnityEditor;
using UnityEngine;

namespace Asteroids.EditorExtensions
{
    public class UnityIconsPreviewer : EditorWindow
    {
        private static string IconNames = "";
        private int IconSize = 32;

        [MenuItem("Window/Built-in icons")]
        public static void ShowWindow()
        {
            GetWindow<UnityIconsPreviewer>();
        }

        private void OnGUI()
        {
            IconSize = EditorGUILayout.IntField("IconSize", IconSize);
            EditorGUILayout.LabelField("Icon names");
            IconNames = EditorGUILayout.TextArea(IconNames, GUILayout.Height(64));

            var names = IconNames.Split('\r', '\n');

            EditorGUILayout.BeginVertical();
            EditorGUILayout.BeginHorizontal();
            for(var i = 0; i < names.Length; i++)
            {
                if (i % 16 == 0)
                {
                    EditorGUILayout.EndHorizontal();
                    EditorGUILayout.BeginHorizontal();
                }
                var iconName = names[i];
                var icon = EditorGUIUtility.IconContent(names[i]).image;
                EditorGUILayout.LabelField(new GUIContent(icon, iconName), GUILayout.Width(IconSize), GUILayout.Height(IconSize));
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndVertical();
        }
    }
}
