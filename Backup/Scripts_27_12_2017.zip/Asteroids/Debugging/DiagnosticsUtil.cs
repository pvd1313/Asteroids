﻿using Stopwatch = System.Diagnostics.Stopwatch;
using System.Collections.Generic;

namespace Abrupt.Debugging
{
    public static class DiagnosticsUtil
    {
        public delegate void SampleMethod();

        private static Dictionary<string, Stopwatch> _watches = new Dictionary<string, Stopwatch>();

        public static void StartSample(string sampleID)
        {
            Stopwatch watch;
            if (!_watches.TryGetValue(sampleID, out watch))
            {
                watch = new Stopwatch();
                _watches.Add(sampleID, watch);
            }
            watch.Reset();
            watch.Start();
        }

        public static double StopSample(string sampleID)
        {
            Stopwatch watch;
            if (!_watches.TryGetValue(sampleID, out watch))
            {
                watch.Stop();
                return watch.ElapsedMilliseconds;
            }
            else
            {
                UnityEngine.Debug.LogErrorFormat("Sample '{0}' not found.");
                return 0;
            }
        }

        public static void ReportSample(string sampleID)
        {
            Stopwatch watch;
            if (!_watches.TryGetValue(sampleID, out watch))
            {
                watch.Stop();
                UnityEngine.Debug.LogFormat("{0} ended in {1}ms", sampleID, watch.ElapsedMilliseconds);
            }
            else
                UnityEngine.Debug.LogErrorFormat("Sample '{0}' not found.");         
        }

        public static void ReportSample(string sampleName, int repeatCount, SampleMethod method)
        {
            var watch = new Stopwatch();
            watch.Start();
            for (var i = 0; i < repeatCount; i++)
                method();
            watch.Stop();
            UnityEngine.Debug.LogFormat("{0}(x{1}) ended in {2}ms", sampleName, repeatCount, watch.ElapsedMilliseconds);
        }
    }
}