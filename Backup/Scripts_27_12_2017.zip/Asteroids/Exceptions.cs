﻿using System;

namespace Asteroids
{
    public class CoreException : Exception
    {
        public CoreException(string format, params string[] args) : base(string.Format(format, args)) { }
    }
}
