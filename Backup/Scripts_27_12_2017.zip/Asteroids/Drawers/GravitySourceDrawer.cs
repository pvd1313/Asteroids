﻿/*using Asteroids.Physics.Gravity;
using UnityEngine;
using Asteroids.Timing;

namespace Asteroids.Drawers
{
    public sealed class GravitySourceDrawer : MonoBehaviour
    {
        public static readonly Color BodyColor = new Color(1, 1, 1, .8f);
        public static readonly Color GravityColor = new Color(.2f, .2f, .2f, .35f);

        GravitySource _source;

        private void Awake()
        {
            _source = GetComponent<GravitySource>();
            if (_source == null)
            {
                Destroy(this);
                throw new CoreException("{0}: {1} not found in '{3}', component will be deleted.", GetType().Name, typeof(GravitySource).Name, name);
            }
        }

        private void OnDrawGizmos()
        {
            var pos = (Vector3) _source.WorldPositionByTime(TimeManager.PreciseTime);
            Gizmos.color = BodyColor;
            GizmosUtil.DrawCircle(pos, Vector3.forward, (float)_source.SurfaceRadius, 36);
            Gizmos.color = GravityColor;
            GizmosUtil.DrawCircle(pos, Vector3.forward, (float)_source.GravityRadius, 36);
        }
    }
}
*/