﻿using Asteroids.Physics.Gravity;
using UnityEngine;
using Asteroids.Timing;

/*namespace Asteroids.Drawers
{
    //TODO: REFACTORE: Add special helper for GravityReceiver, which will help to draw related info.
    public sealed class GravityReceiverDrawer : MonoBehaviour
    {
        public static readonly int TrajectoryTopology = 60;
        public static readonly Color TrajectoryColor = new Color(.5f, .5f, .5f, .5f);
        public static readonly Color EventColor = new Color(1f, 0, 0, .7f);
        public static readonly Color EventTimeCurveColor = new Color(1f, 0, 0, .3f);
        public static readonly Color TimeTextColor = new Color(1f, .7f, .7f, .7f);
        public static readonly Color ApocenterColor = new Color(0, .7f, 0, .5f);
        public static readonly Color PericenterColor = new Color(.7f, 0, 0, .5f);

        GravityReceiver _receiver;
        Camera _camera;

        private void Awake()
        {
            _receiver = GetComponent<GravityReceiver>();
            _camera = FindObjectOfType<Camera>();
            if (_receiver == null)
            {
                Destroy(this);
                throw new CoreException("{0}: {1} not found in '{3}', component will be deleted.", GetType().Name, typeof(GravityReceiver).Name, name);
            }
        }

        private void OnDrawGizmos()
        { 
            var motionCurve = _receiver.CalculateMotionCurve(TimeManager.PreciseTime, TrajectoryTopology);
            Gizmos.color = TrajectoryColor;
            GizmosUtil.DrawCurve(motionCurve.Points, motionCurve.IsLooped);
            if (_receiver.HasEvent)
            {
                Gizmos.color = EventColor;
                var parentPosAtEvent = _receiver.ParentWorldPositionByTime(_receiver.NextEventTime);
                var eventLocalPos = (Vector3)(_receiver.ParentWorldPositionByTime(TimeManager.PreciseTime) + _receiver.LocalPositionByTime(_receiver.NextEventTime));
                var eventPos = (Vector3)_receiver.WorldPositionByTime(_receiver.NextEventTime);
                GizmosUtil.DrawCircle(eventLocalPos, Vector3.forward, 3, 9);
                GizmosUtil.DrawCircle(eventPos, Vector3.forward, 3, 9);
                Gizmos.color = TrajectoryColor;
                GizmosUtil.DrawCircle((Vector3)parentPosAtEvent, Vector3.forward, 3, 9);
                Gizmos.DrawLine((Vector3)parentPosAtEvent, eventPos);
                Gizmos.color = EventTimeCurveColor;
                Gizmos.DrawLine(eventLocalPos, eventPos);
            }
        }

        private void OnDrawGizmosSelected()
        {
            if (!_receiver.HasEvent)
            {
                var apsis = _receiver.WorldApsisByTime(TimeManager.PreciseTime);
                Gizmos.color = ApocenterColor;
                GizmosUtil.DrawCircle((Vector3)apsis.Apocenter, Vector3.forward, 3, 3);
                Gizmos.color = PericenterColor;
                GizmosUtil.DrawCircle((Vector3)apsis.Pericenter, Vector3.forward, 3, 3);
            }
        }

        private void OnGUI()
        {
            if (_receiver.HasEvent)
            {
                var eventLocalPos = _receiver.ParentWorldPositionByTime(TimeManager.PreciseTime) + _receiver.LocalPositionByTime(_receiver.NextEventTime);
                var timeText = string.Format("{0:F1}s", _receiver.NextEventTime - TimeManager.PreciseTime);
                GUI.color = TimeTextColor;
                GUIUtil.DrawLabel((Vector3) eventLocalPos, 32, timeText);
                GUIUtil.DrawLabel((Vector3)_receiver.WorldPositionByTime(_receiver.NextEventTime), 32, timeText);
            }
        }
    }
}*/