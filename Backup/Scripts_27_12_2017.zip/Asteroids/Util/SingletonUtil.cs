﻿using UnityEngine;

namespace Asteroids
{
    public static class SingletonUtil
    {
        public static T Create<T>() where T : MonoBehaviour
        {
            var obj = new GameObject(typeof(T).Name);
            var singleton = obj.AddComponent<T>();
            Object.DontDestroyOnLoad(obj);
            return singleton;
        }
    }
}