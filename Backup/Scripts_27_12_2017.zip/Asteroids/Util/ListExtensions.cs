﻿using System;
using System.Collections.Generic;

namespace Asteroids
{
    public static class ListExtensions
    {
        public static LinkedListNode<T> FindFirst<T>(this LinkedList<T> list, Predicate<T> predicate)
        {
            var node = list.First;
            while (node != null && !predicate(node.Value))
                node = node.Next;
            return node;
        }

    }
}
