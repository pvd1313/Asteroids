﻿using UnityEngine;

namespace Asteroids
{
    public static class GUIUtil
    {
        private static readonly Camera CurrentCamera = GameObject.FindObjectOfType<Camera>();

        public static void DrawLabel(Vector3 worldPosition, float width, string text)
        {
            var screenPos = CurrentCamera.WorldToScreenPoint(worldPosition);
            GUI.Label(new Rect(screenPos.x, Screen.height - screenPos.y, width, 24), text);
        }
    }
}
