﻿using UnityEngine;

namespace Asteroids
{
    public static class MonoUtil
    {
        public static T CreateGameObjectWithComponent<T>(string name) where T : MonoBehaviour
        {
            var obj = new GameObject();
            obj.name = name;
            return obj.AddComponent<T>();
        }
    }
}
