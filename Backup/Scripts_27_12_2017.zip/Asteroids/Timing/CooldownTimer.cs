﻿using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Asteroids.Timing
{
    [System.Serializable]
    public class CooldownTimer
    {
        [SerializeField]
        private float _cooldown;
        private float _nextUse;

        public float Cooldown { get { return _cooldown; } }

        public float Progress
        {
            get
            {
                var currentTime = TimeManager.Time;
                var timeLeft = _nextUse - currentTime;
                if (timeLeft <= 0) return 1;
                return (1 - timeLeft / Cooldown);
            }
        }

        public CooldownTimer(float cooldown)
        {
            _cooldown = cooldown;
        }

        public bool TryReset()
        {
            var currentTime = TimeManager.Time;
            if (currentTime >= _nextUse)
            {
                _nextUse = currentTime + _cooldown;
                return true;
            }
            return false;
        }
    }

#if UNITY_EDITOR
    [CustomPropertyDrawer(typeof(CooldownTimer))]
    internal class CooldownTimerDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var icon = EditorGUIUtility.IconContent("SpeedScale").image;
            position.width -= 18;
            var prop = property.FindPropertyRelative("_cooldown");
            EditorGUI.PropertyField(position, prop, new GUIContent(label.text, icon, "Cooldown measured in seconds."));

            position.x = position.width + 13 - EditorGUI.indentLevel * 15;
            EditorGUI.LabelField(position, "sec");
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return 16;
        }
    }
#endif
}