﻿using UnityEngine;

namespace Asteroids.Timing
{
    public class TimeManager : MonoBehaviour
    {
        public static float Time { get; private set; }
        public static double PreciseTime { get; private set; }

        static TimeManager()
        {
            SingletonUtil.Create<TimeManager>();
        }

        private void LateUpdate()
        {
            PreciseTime += UnityEngine.Time.deltaTime;
            Time = (float)PreciseTime;
        }
    }
}