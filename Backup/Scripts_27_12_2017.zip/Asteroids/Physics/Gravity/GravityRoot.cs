﻿using UnityEngine;
using Abrupt;

namespace Asteroids.Physics.Gravity
{
    public class GravityRoot : GravitySource
    {
        public static readonly GravityRoot Reference;

        static GravityRoot()
        {
            Reference = SingletonUtil.Create<GravityRoot>();
        }

        protected override void Awake() { }

        public override CelestialTrajectory CreateTrajectory(TrajectoryPhysicalProperties trajectoryProperties)
        {
            return new EmptyTrajectory(trajectoryProperties);
        }

        public override PlanarVector WorldPositionByTime(double time) { return PlanarVector.Zero; }
        public override PlanarVector WorldVelocityByTime(double time) { return PlanarVector.Zero; }
        public override PlanarVector ParentWorldPositionByTime(double time) { return PlanarVector.Zero; }
        public override PlanarVector ParentWorldVelocityByTime(double time) { return PlanarVector.Zero; }
        public override PlanarVector LocalPositionByTime(double time) { return PlanarVector.Zero; }
        public override PlanarVector LocalVelocityByTime(double time) { return PlanarVector.Zero; }
        public override bool IsWorldPointInside(Vector3 worldPoint) { return true; }
    }
}