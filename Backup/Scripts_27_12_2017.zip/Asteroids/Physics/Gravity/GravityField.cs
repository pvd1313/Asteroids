﻿namespace Asteroids.Physics.Gravity
{
    public struct GravityField
    {
        public MinMax Gravity;
        public double Radius;

        public GravityField(double radius, MinMax gravity)
        {
            Radius = radius;
            Gravity = gravity;
        }
    }
}
