﻿namespace Asteroids.Physics.Gravity
{
    public struct PhysicalOrbit
    {
        public PlanarVector Eccentricity;
        public double AngularMomentum;
        public double Mass;

        public PhysicalOrbit(PlanarVector eccentricity, double angularMomentum, double mass)
        {
            Eccentricity = eccentricity;
            AngularMomentum = angularMomentum;
            Mass = mass;
        }
    }
}
