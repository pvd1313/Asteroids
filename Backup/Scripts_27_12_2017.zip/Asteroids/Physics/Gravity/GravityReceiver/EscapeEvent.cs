﻿namespace Asteroids.Physics.Gravity
{
    public partial class GravityReceiver
    {
        public class EscapeEvent : Event
        {
            public EscapeEvent(GravityReceiver receiver, GravitySource source, double time) : base(receiver, source, time) { }

            public override void Invoke()
            {
                /*var position = _trajectory.PositionByTime(time);
                var parentPos = _parent._trajectory.PositionByTime(time);
                var newVelocity = _parent._trajectory.VelocityAtLocalPoint(position, time);
                ChangeParent(_parent._parent);
                var newBody = new CelestialBody(parentPos + position, newVelocity, time);
                ChangeTrajectory(_parent.CreateTrajectory(newBody));*/

                var body = new PhysicalBody(Receiver.WorldPositionByTime(InvokationTime), Receiver.WorldVelocityByTime(InvokationTime), InvokationTime);
                var newParent = Source._parent;
                Receiver.ChangeParent(newParent);
                Receiver.ChangeTrajectory(newParent.CreateTrajectory(Receiver.WorldToLocalBody(body)), InvokationTime);
            }
        }
    }
}