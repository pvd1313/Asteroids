﻿using System;

namespace Asteroids.Physics.Gravity
{
    public partial class GravityReceiver
    {
        public class JoinEvent : Event
        {
            public JoinEvent(GravityReceiver receiver, GravitySource source, double time) : base(receiver, source, time) { }

            public override void Invoke()
            {
                throw new NotImplementedException();
            }
        }
    }
}
