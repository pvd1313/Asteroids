﻿using UnityEngine;

namespace Asteroids.Physics.Gravity
{
    public partial class GravityReceiver
    {
        public class FallEvent : Event
        {
            public FallEvent(GravityReceiver receiver, GravitySource source, double time) : base(receiver, source, time) { }

            public override void Invoke()
            {
                Destroy(Receiver.gameObject);
            }
        }
    }
}