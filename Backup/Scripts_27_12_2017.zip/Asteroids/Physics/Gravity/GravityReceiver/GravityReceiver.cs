﻿using UnityEngine;
using Asteroids.Timing;

namespace Asteroids.Physics.Gravity
{
    public partial class GravityReceiver : MonoBehaviour
    {
        private GravitySource _parent;
        protected CelestialTrajectory _trajectory;
        private Event _nextEvent;

        public virtual void ChangeVelocity(PlanarVector deltaVelocity, double changeTime)
        {
            var currentPos = _trajectory.PositionByTime(changeTime);
            var currentVel = _trajectory.VelocityByTime(changeTime) + deltaVelocity;
            var body = new PhysicalBody(currentPos, currentVel, changeTime);
            ChangeTrajectory(_parent.CreateTrajectory(body), changeTime);
        }

        public bool HasEvent { get { return _nextEvent != null; } }
        public double NextEventTime { get { return _nextEvent.InvokationTime; } }

        public virtual PlanarVector WorldPositionByTime(double time)
        {
            return _parent.WorldPositionByTime(time) + _trajectory.PositionByTime(time);
        }

        public virtual PlanarVector WorldVelocityByTime(double time)
        {
            return ParentWorldVelocityByTime(time) + _trajectory.VelocityByTime(time);
        }

        // TODO: REFACTORE: Move to helper class.
        public virtual TrajectoryApsis WorldApsisByTime(double time)
        {
            var parentPos = ParentWorldPositionByTime(time);
            var apsis = _trajectory.Apsis;
            return new TrajectoryApsis(parentPos + apsis.Apocenter, parentPos + apsis.Pericenter);
        }

        // TODO: REFACTORE: Remove.
        public virtual PlanarVector ParentWorldPositionByTime(double time)
        {
            return _parent.WorldPositionByTime(time);
        }

        // TODO: REFACTORE: Remove.
        public virtual PlanarVector ParentWorldVelocityByTime(double time)
        {
            return _parent.WorldVelocityByTime(time);
        }

        public virtual PlanarVector LocalPositionByTime(double time)
        {
            return _trajectory.PositionByTime(time);
        }

        public virtual PlanarVector LocalVelocityByTime(double time)
        {
            return _trajectory.VelocityByTime(time);
        }

        // TODO: REFACTORE: Move to GravitySource.
        public void UpdatePosition()
        {
            transform.position = (Vector3)WorldPositionByTime(TimeManager.PreciseTime);
        }

        protected virtual void Awake()
        {
            if (_parent == null) ChangeParent(FindParent());
            if (_trajectory == null)
            {
                Destroy(this);
                //throw new System.Exception("Trajectory is null.");
            }
            //ChangeTrajectory(_parent.CreateTrajectory(WorldToLocalBody(worldBody)), worldBody.Time);
        }

        // TODO: REFACTORE: Move to GravitySource.
        private PhysicalBody WorldToLocalBody(PhysicalBody worldBody)
        {
            worldBody.Position = worldBody.Position - ParentWorldPositionByTime(worldBody.Time);
            worldBody.Velocity = worldBody.Velocity - ParentWorldVelocityByTime(worldBody.Time);
            return worldBody;
        }

        private GravitySource FindParent()
        {
            var result = GravityRoot.Reference as GravitySource;
            foreach (var source in FindObjectsOfType<GravitySource>())
            {
                if (source == this) continue;
                if (CanBeInside(source) && source.GravityRadius < result.GravityRadius)
                    result = source;
            }
            return result;
        }

        private void ChangeParent(GravitySource newParent)
        {
            if (_parent != null) _parent.RemoveChild(this);
            _parent = newParent;
            if (_parent != null) _parent.AddChild(this);
        }

        private void ChangeTrajectory(CelestialTrajectory trajectory, double currentTime)
        {
            if (_nextEvent != null) GravityManager.UnregisterEvent(_nextEvent);
            _trajectory = trajectory;
            _nextEvent = FindNextEvent(trajectory, currentTime);
            if (_nextEvent != null) GravityManager.RegisterEvent(_nextEvent);
        }

        private Event FindNextEvent(CelestialTrajectory trajectory, double currentTime)
        {
            var calculator = new CelestialTrajectory.EventCalculator(trajectory, _parent);
            var trajectoryEvent = calculator.Predict(currentTime);
            return Event.Convert(trajectoryEvent, this);
        }

        protected virtual bool CanBeInside(GravitySource target)
        {
            return target.IsWorldPointInside(transform.position);
        }
        
        public MotionCurve CalculateMotionCurve(double currentTime, int topology)
        {
            PlanarVector[] curve;
            if (_nextEvent == null) curve = _trajectory.CalculateMotionCurve(topology);
            else curve = _trajectory.CalculateMotionCurve(currentTime, _nextEvent.InvokationTime, topology);
            
            var center = ParentWorldPositionByTime(currentTime);
            var unityCurve = new Vector3[curve.Length];
            for (var i = 0; i < curve.Length; i++)
                unityCurve[i] = (Vector3)(center + curve[i]);
            return new MotionCurve(unityCurve, _nextEvent == null);
        }

        protected virtual void OnDestroy()
        {
            if (_parent != null) _parent.RemoveChild(this);
        }
    }
}