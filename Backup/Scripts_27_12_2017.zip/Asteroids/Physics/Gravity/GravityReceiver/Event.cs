﻿namespace Asteroids.Physics.Gravity
{
    public partial class GravityReceiver
    {
        public abstract class Event : TimeBasedEvent
        {
            protected readonly GravityReceiver Receiver;
            protected readonly GravitySource Source;

            public Event(GravityReceiver receiver, GravitySource source, double time) : base(time)
            {
                Receiver = receiver;
                Source = source;
            }

            public static Event Convert(CelestialTrajectory.Event trajectoryEvent, GravityReceiver receiver)
            {
                if (trajectoryEvent == null) return null;
                var eventType = trajectoryEvent.Category;
                switch(eventType)
                {
                    case CelestialTrajectory.Event.Types.Escape:
                        return new EscapeEvent(receiver, trajectoryEvent.Source, trajectoryEvent.Time);
                    case CelestialTrajectory.Event.Types.Fall:
                        return new FallEvent(receiver, trajectoryEvent.Source, trajectoryEvent.Time);
                    case CelestialTrajectory.Event.Types.Join:
                        return new JoinEvent(receiver, trajectoryEvent.Source, trajectoryEvent.Time);
                    default:
                        throw new System.NotSupportedException();
                }
            }
        }
    }
}