﻿using UnityEngine;

namespace Asteroids.Physics.Gravity
{
    public struct MotionCurve
    {
        public readonly Vector3[] Points;
        public readonly bool IsLooped;

        public MotionCurve(Vector3[] points, bool isLooped)
        {
            Points = points;
            IsLooped = isLooped;
        }
    }
}