﻿using System;

namespace Asteroids.Physics.Gravity
{
    // TODO: RENAME: Find more suitable name (circular trajectory also curved, this name is not accurate).
    public abstract class CurvedTrajectory : KeplerTrajectory
    {
        protected readonly double Eccentricity;
        protected PlanarRotation Inclanation;
        protected PlanarVector CoordinatesModificator;

        public CurvedTrajectory(TrajectoryPhysicalProperties trajectoryProperties) : base(trajectoryProperties)
        {
            Eccentricity = trajectoryProperties.Orbit.Eccentricity.Magnitude;
        }

        protected double TrueAnomalyFromAttitude(double attitude)
        {
            var focalParameter = SemiMajorAxis * (1 - Eccentricity * Eccentricity);
            var trueAnomaly = Math.Acos((focalParameter / attitude - 1) / Eccentricity);
            if (double.IsNaN(trueAnomaly)) return 0;
            return trueAnomaly;
        }
    }
}
