﻿using System;

namespace Asteroids.Physics.Gravity
{
    public class EllipticTrajectory : CurvedTrajectory
    {
        public static bool IsElliptic(TrajectoryPhysicalProperties trajectoryProperties)
        {
            return trajectoryProperties.Orbit.Eccentricity.Magnitude < 1;
        }

        public EllipticTrajectory(TrajectoryPhysicalProperties trajectoryProperties) : base(trajectoryProperties)
        {
            SemiMajorAxis = trajectoryProperties.Orbit.AngularMomentum * trajectoryProperties.Orbit.AngularMomentum / Mass / (1 - Eccentricity * Eccentricity);
            Inclanation = new PlanarRotation(Math.Atan2(trajectoryProperties.Orbit.Eccentricity.Y, trajectoryProperties.Orbit.Eccentricity.X));

            var apocenter = Inclanation.RotateXAxis(-SemiMajorAxis * (1 + Eccentricity));
            var pericenter = Inclanation.RotateXAxis(SemiMajorAxis * (1 - Eccentricity));
            Apsis = new TrajectoryApsis(apocenter, pericenter);

            CreationMeanAnomaly = MeanFromLocalAnomaly(LocalAnomalyFromPosition(trajectoryProperties.Body.Position));
            MeanVelocity = FindMeanVelocity(SemiMajorAxis, trajectoryProperties.Orbit.AngularMomentum);
            CoordinatesModificator = new PlanarVector(-SemiMajorAxis * Eccentricity, SemiMajorAxis * Math.Sqrt(1 - Eccentricity * Eccentricity));
        }

        public double LocalAnomalyFromPosition(PlanarVector position)
        {
            position = Inclanation.InvertedRotate(position);
            var eccentricitySin = position.Y / SemiMajorAxis / Math.Sqrt(1 - Eccentricity * Eccentricity);
            var eccentricityCos = position.X / SemiMajorAxis + Eccentricity;
            return Math.Atan2(eccentricitySin, eccentricityCos);
        }

        public override PlanarVector[] CalculateMotionCurve(int topology)
        {
            return MotionCurveFromAngleRotation(PositionFromLocalAnomaly, 0, MathUtil.TWO_PI, topology);
        }

        public override PlanarVector[] CalculateMotionCurve(double startTime, double endTime, int topology)
        {
            var startAngle = LocalFromMeanAnomaly(MeanAnomalyByTime(startTime));
            var endAngle = LocalFromMeanAnomaly(MeanAnomalyByTime(endTime));
            if (MeanVelocity > 0)
                return MotionCurveFromAngleRotation(PositionFromLocalAnomaly, startAngle, MathUtil.CreateClockwiseRotationAngle(startAngle, endAngle), topology);
            return MotionCurveFromAngleRotation(PositionFromLocalAnomaly, startAngle, MathUtil.CreateCounterclockwiseRotationAngle(startAngle, endAngle), topology);
        }

        public PlanarVector PositionFromLocalAnomaly(double localAnomaly)
        {
            PlanarVector pos;
            pos.X = SemiMajorAxis * Math.Cos(localAnomaly) + CoordinatesModificator.X;
            pos.Y = Math.Sin(localAnomaly) * CoordinatesModificator.Y;
            return Inclanation.Rotate(pos);
        }

        public override PlanarVector VelocityByTime(double time)
        {
            var trueAnomaly = TrueFromLocalAnomaly(LocalFromMeanAnomaly(MeanAnomalyByTime(time)));
            var sqrtParam = Math.Sqrt(Mass / (SemiMajorAxis * (1 - Eccentricity * Eccentricity)));
            PlanarVector vel;
            vel.X = -sqrtParam * Math.Sin(trueAnomaly);
            vel.Y = sqrtParam * (Eccentricity + Math.Cos(trueAnomaly));
            return Inclanation.Rotate(vel) * Math.Sign(MeanVelocity);
        }

        protected double LocalFromTrueAnomaly(double trueAnomaly)
        {
            var sqrtParam = Math.Sqrt((1 + Eccentricity) / (1 - Eccentricity));
            return Math.Atan(Math.Tan(trueAnomaly / 2) / sqrtParam) * 2;
        }

        protected double TrueFromLocalAnomaly(double localAnomaly)
        {
            return Math.Atan2(Math.Sqrt(1 - Eccentricity * Eccentricity) * Math.Sin(localAnomaly), (Math.Cos(localAnomaly) - Eccentricity));
        }

        protected double LocalFromMeanAnomaly(double meanAnomaly)
        {
            var newAnomaly = meanAnomaly;
            var oldAnomaly = newAnomaly;
            do
            {
                oldAnomaly = newAnomaly;
                var function = oldAnomaly - Eccentricity * Math.Sin(oldAnomaly) - meanAnomaly;
                var derivative = 1 - Eccentricity * Math.Cos(oldAnomaly);
                newAnomaly = oldAnomaly - function / derivative;
            } while (Math.Abs(oldAnomaly - newAnomaly) > GeneralAccuracy);
            return newAnomaly;
        }

        protected double MeanFromLocalAnomaly(double localAnomaly)
        {
            return localAnomaly - Math.Sin(localAnomaly) * Eccentricity;
        }

        public override double FindNearestAproachTimeByAttitude(double currentTime, double targetAttitude)
        {
            var currentAnomaly = MeanAnomalyByTime(currentTime);
            var aproachAnomaly = MeanFromLocalAnomaly(LocalFromTrueAnomaly(TrueAnomalyFromAttitude(targetAttitude)));
            var deltaTime0 = FindRequiredTimeToPass(currentAnomaly, aproachAnomaly);
            var deltaTime1 = FindRequiredTimeToPass(currentAnomaly, -aproachAnomaly);
            return currentTime + Math.Min(deltaTime0, deltaTime1);
        }

        private double FindRequiredTimeToPass(double startMeanAnomaly, double endMeanAnomaly)
        {
            if (MeanVelocity > 0)
                return MathUtil.CreateClockwiseRotationAngle(startMeanAnomaly, endMeanAnomaly) / MeanVelocity;
            else
                return MathUtil.CreateCounterclockwiseRotationAngle(startMeanAnomaly, endMeanAnomaly) / MeanVelocity;
        }

        public override PlanarVector VelocityAtLocalPoint(PlanarVector localPoint, double time)
        {
            var childPosition = PositionByTime(time) + localPoint;
            var childProjectedPosition = Project(childPosition);
            var deltaRadius = (childProjectedPosition - childPosition).Magnitude;
            if (childPosition.Magnitude < childProjectedPosition.Magnitude) deltaRadius = -deltaRadius;

            var newMajorAxis = SemiMajorAxis + deltaRadius;
            var newMinorAxis = SemiMajorAxis * Math.Sqrt(1 - Eccentricity * Eccentricity) + deltaRadius;
            var newEccentricity = Math.Sqrt(1 - (newMinorAxis * newMinorAxis) / (newMajorAxis * newMajorAxis));
            var newMomentum = TrajectoryPhysicalProperties.FindAbsoluteAngularMomentum(newMajorAxis, newEccentricity, Mass) * Math.Sign(MeanVelocity);
            var newOrbit = new PhysicalOrbit(Inclanation.RotateXAxis(newEccentricity), newMomentum, Mass);

            return TrajectoryPhysicalProperties.FindVelocity(newOrbit, childPosition);
        }

        public override PlanarVector PositionByTime(double time)
        {
            var localAnomaly = LocalFromMeanAnomaly(MeanAnomalyByTime(time));
            return PositionFromLocalAnomaly(localAnomaly);
        }

        public override PlanarVector Project(PlanarVector position)
        {
            return PositionFromLocalAnomaly(LocalAnomalyFromPosition(position));
        }
    }
}