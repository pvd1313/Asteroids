﻿using System;

namespace Asteroids.Physics.Gravity
{
    // Make this trajectory as gag, make objects not move while on this trajectory.
    public class EmptyTrajectory : CelestialTrajectory
    {
        private static PlanarVector[] EmptyMotionCurve = new PlanarVector[] { };

        private readonly PlanarVector _position;
        
        public EmptyTrajectory(TrajectoryPhysicalProperties trajectoryProperties) : base(trajectoryProperties)
        {
            _position = trajectoryProperties.Body.Position;
            Apsis = new TrajectoryApsis(_position, _position);
        }

        public override PlanarVector[] CalculateMotionCurve(int topology)
        {
            var curve = new PlanarVector[topology];
            for (var i = 0; i < topology; i++)
                curve[i] = _position;
            return curve;
        }

        public override PlanarVector[] CalculateMotionCurve(double startTime, double endTime, int topology)
        {
            return EmptyMotionCurve;
        }

        public override PlanarVector PositionByTime(double time)
        {
            return _position;
        }

        public override PlanarVector VelocityByTime(double time)
        {
            return PlanarVector.Zero;
        }

        public override PlanarVector Project(PlanarVector position)
        {
            return _position;
        }

        public override double FindNearestAproachTimeByAttitude(double currentTime, double targetAttitude)
        {
            throw new NotSupportedException();
        }

        public override PlanarVector VelocityAtLocalPoint(PlanarVector localPoint, double time)
        {
            return PlanarVector.Zero;
        }
    }
}