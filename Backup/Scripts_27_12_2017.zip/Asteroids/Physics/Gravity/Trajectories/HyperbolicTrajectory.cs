﻿using System;

namespace Asteroids.Physics.Gravity
{
    public class HyperbolicTrajectory : CurvedTrajectory
    {
        public static bool IsHyperbolic(TrajectoryPhysicalProperties trajectoryProperties)
        {
            return trajectoryProperties.Orbit.Eccentricity.Magnitude >= 1;
        }

        public HyperbolicTrajectory(TrajectoryPhysicalProperties trajectoryProperties) : base(trajectoryProperties)
        {
            var velocity = trajectoryProperties.Body.Velocity.Magnitude;
            SemiMajorAxis = 1 / (2 / trajectoryProperties.Body.Position.Magnitude - velocity * velocity / trajectoryProperties.Orbit.Mass);
            Inclanation = new PlanarRotation(Math.Atan2(-trajectoryProperties.Orbit.Eccentricity.Y, -trajectoryProperties.Orbit.Eccentricity.X));

            var apocenter = Inclanation.RotateXAxis(float.MinValue);
            var pericenter = Inclanation.RotateXAxis(SemiMajorAxis * (1 - Eccentricity));
            Apsis = new TrajectoryApsis(apocenter, pericenter);

            CreationMeanAnomaly = MeanFromLocalAnomaly(LocalAnomalyFromPosition(trajectoryProperties.Body.Position));
            MeanVelocity = FindMeanVelocity(SemiMajorAxis, trajectoryProperties.Orbit.AngularMomentum);
            CoordinatesModificator = new PlanarVector(SemiMajorAxis * Eccentricity, SemiMajorAxis * Math.Sqrt(Eccentricity * Eccentricity - 1));
        }

        public override PlanarVector VelocityByTime(double time)
        {
            var localAnomaly = LocalFromMeanAnomaly(MeanAnomalyByTime(time));
            var timeDerivative = (Eccentricity * Math.Cosh(localAnomaly) - 1) / MeanVelocity;
            PlanarVector velocity;
            velocity.X = -SemiMajorAxis * Math.Sinh(localAnomaly) / timeDerivative;
            velocity.Y = CoordinatesModificator.Y * Math.Cosh(localAnomaly) / timeDerivative;
            return Inclanation.Rotate(velocity);
        }

        public override double FindNearestAproachTimeByAttitude(double currentTime, double targetAttitude)
        {
            var currentMeanAnomaly = MeanAnomalyByTime(currentTime);
            var aproachAnomaly = MeanFromLocalAnomaly(LocalFromTrueAnomaly(TrueAnomalyFromAttitude(targetAttitude)));
            var deltaTime0 = FindRequiredTimeToPass(currentMeanAnomaly, aproachAnomaly);
            var deltaTime1 = FindRequiredTimeToPass(currentMeanAnomaly, -aproachAnomaly);
            if (deltaTime0 > 0)
            {
                if (deltaTime1 < 0) return currentTime + deltaTime0;
                return currentTime + Math.Min(deltaTime0, deltaTime1);
            }
            else
            {
                if (deltaTime1 > 0) return currentTime + deltaTime1;
                return currentTime + Math.Max(deltaTime0, deltaTime1);
            }
        }

        private double FindRequiredTimeToPass(double startMeanAnomaly, double endMeanAnomaly)
        {
            return (endMeanAnomaly - startMeanAnomaly) / MeanVelocity;
        }

        public override PlanarVector[] CalculateMotionCurve(int topology)
        {
            return MotionCurveFromAngleRotation(PositionFromLocalAnomaly, -Math.PI, MathUtil.TWO_PI, topology);
        }

        public override PlanarVector[] CalculateMotionCurve(double startTime, double endTime, int topology)
        {
            var startAngle = LocalFromMeanAnomaly(MeanAnomalyByTime(startTime));
            var endAngle = LocalFromMeanAnomaly(MeanAnomalyByTime(endTime));
            return MotionCurveFromAngleRotation(PositionFromLocalAnomaly, startAngle, endAngle - startAngle, topology);
        }

        public PlanarVector PositionFromLocalAnomaly(double localAnomaly)
        {
            PlanarVector pos;
            pos.X = CoordinatesModificator.X - SemiMajorAxis * Math.Cosh(localAnomaly);
            pos.Y = CoordinatesModificator.Y * Math.Sinh(localAnomaly);
            return Inclanation.Rotate(pos);
        }

        protected double LocalFromTrueAnomaly(double trueAnomaly)
        {
            var sqrtParam = Math.Sqrt((Eccentricity + 1) / (Eccentricity - 1));
            return MathUtil.Atanh(Math.Tan(trueAnomaly / 2) / sqrtParam) * 2;
        }

        protected double TrueFromLocalAnomaly(double localAnomaly)
        {
            throw new NotImplementedException();
        }

        protected double LocalFromMeanAnomaly(double meanAnomaly)
        {
            var newAnomaly = meanAnomaly;
            var oldAnomaly = newAnomaly;
            do
            {
                oldAnomaly = newAnomaly;
                var function = meanAnomaly - Eccentricity * Math.Sinh(oldAnomaly) + oldAnomaly;
                var derivative = Eccentricity * Math.Cosh(oldAnomaly) - 1;
                newAnomaly = oldAnomaly + function / derivative;
            } while (Math.Abs(oldAnomaly - newAnomaly) > GeneralAccuracy);
            return newAnomaly;
        }

        protected double MeanFromLocalAnomaly(double localAnomaly)
        {
            return Eccentricity * Math.Sinh(localAnomaly) - localAnomaly;
        }

        public double LocalAnomalyFromPosition(PlanarVector position)
        {
            position = Inclanation.InvertedRotate(position);
            var cosh = Eccentricity - position.X / SemiMajorAxis;
            var sinh = position.Y / SemiMajorAxis / Math.Sqrt(Eccentricity * Eccentricity - 1);
            return MathUtil.Atanh(sinh / cosh);
        }

        public override PlanarVector VelocityAtLocalPoint(PlanarVector localPoint, double time)
        {
            throw new NotImplementedException();
        }

        public override PlanarVector PositionByTime(double time)
        {
            var localAnomaly = LocalFromMeanAnomaly(MeanAnomalyByTime(time));
            return PositionFromLocalAnomaly(localAnomaly);
        }

        public override PlanarVector Project(PlanarVector position)
        {
            return PositionFromLocalAnomaly(LocalAnomalyFromPosition(position));
        }
    }
}