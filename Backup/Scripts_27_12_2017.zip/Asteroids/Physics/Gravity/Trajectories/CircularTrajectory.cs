﻿using System;

namespace Asteroids.Physics.Gravity
{
    public class CircularTrajectory : KeplerTrajectory
    {
        private const double CircularOrbitEccentricityThreshold = 0.02;

        public static bool IsCircular(TrajectoryPhysicalProperties trajectoryProperties)
        {
            return trajectoryProperties.Orbit.Eccentricity.Magnitude <= CircularOrbitEccentricityThreshold;
        }

        public CircularTrajectory(TrajectoryPhysicalProperties trajectoryProperties) : base(trajectoryProperties)
        {
            SemiMajorAxis = trajectoryProperties.Body.Position.Magnitude;
            Apsis = new TrajectoryApsis(new PlanarVector(SemiMajorAxis, 0), new PlanarVector(-SemiMajorAxis, 0));
            CreationMeanAnomaly = LocalAnomalyFromPosition(trajectoryProperties.Body.Position);
            MeanVelocity = FindMeanVelocity(SemiMajorAxis, trajectoryProperties.Orbit.AngularMomentum);
            
        }

        public double LocalAnomalyFromPosition(PlanarVector position)
        {
            return Math.Atan2(position.Y, position.X);
        }

        public override PlanarVector[] CalculateMotionCurve(int topology)
        {
            return MotionCurveFromAngleRotation(PositionFromLocalAnomaly, 0, MathUtil.TWO_PI, topology);
        }

        public override PlanarVector[] CalculateMotionCurve(double startTime, double endTime, int topology)
        {
            var startAngle = MeanAnomalyByTime(startTime);
            var endAngle = MeanAnomalyByTime(endTime);
            if (MeanVelocity > 0)
                return MotionCurveFromAngleRotation(PositionFromLocalAnomaly, startAngle, MathUtil.CreateClockwiseRotationAngle(startAngle, endAngle), topology);
            return MotionCurveFromAngleRotation(PositionFromLocalAnomaly, startAngle, MathUtil.CreateCounterclockwiseRotationAngle(startAngle, endAngle), topology);
        }

        public override PlanarVector PositionByTime(double time)
        {
            return PositionFromLocalAnomaly(MeanAnomalyByTime(time));
        }

        public PlanarVector PositionFromLocalAnomaly(double localAnomaly)
        {
            return PlanarRotation.RotateXAxis(SemiMajorAxis, localAnomaly);
        }

        public override PlanarVector VelocityByTime(double time)
        {
            var velocity = Math.Sqrt(Mass / SemiMajorAxis);
            return PlanarRotation.RotateXAxis(velocity, MeanAnomalyByTime(time) + Math.PI / 2) * Math.Sign(MeanVelocity);
        }

        public override PlanarVector VelocityAtLocalPoint(PlanarVector localPoint, double time)
        {
            var childPosition = PositionByTime(time) + localPoint;
            var childProjectedPosition = Project(childPosition);
            var deltaRadius = (childProjectedPosition - childPosition).Magnitude;
            if (childPosition.Magnitude < childProjectedPosition.Magnitude) deltaRadius = -deltaRadius;

            var newMomentum = TrajectoryPhysicalProperties.FindAbsoluteAngularMomentum(SemiMajorAxis + deltaRadius, 0, Mass) * Math.Sign(MeanVelocity);
            var newOrbit = new PhysicalOrbit(PlanarVector.Zero, newMomentum, Mass);
            return TrajectoryPhysicalProperties.FindVelocity(newOrbit, childPosition);
        }

        public override PlanarVector Project(PlanarVector position)
        {
            return PositionFromLocalAnomaly(LocalAnomalyFromPosition(position));
        }

        // TODO: IMPLEMENT: FindNearestAproachTimeByAttitude(double currentTime, double targetAttitude)
        public override double FindNearestAproachTimeByAttitude(double currentTime, double targetAttitude)
        {
            throw new NotImplementedException();
        }
    }
}