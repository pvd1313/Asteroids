﻿namespace Asteroids.Physics.Gravity
{
    partial class CelestialTrajectory
    {
        public class Event
        {
            public enum Types { Escape, Fall, Join };

            public readonly Types Category;
            public readonly double Time;
            public readonly GravitySource Source;

            public Event(Types category, double time, GravitySource source)
            {
                Category = category;
                Time = time;
                Source = source;
            }
        }
    }
}