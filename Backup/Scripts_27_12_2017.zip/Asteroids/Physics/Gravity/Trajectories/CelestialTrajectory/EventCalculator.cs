﻿namespace Asteroids.Physics.Gravity
{
    partial class CelestialTrajectory
    {
        public class EventCalculator
        {
            private readonly CelestialTrajectory _trajectory;
            private readonly TrajectoryApsis _trajectoryApsis;
            private readonly GravitySource _parent;

            public EventCalculator(CelestialTrajectory trajectory, GravitySource parent)
            {
                _trajectory = trajectory;
                _trajectoryApsis = _trajectory.Apsis;
                _parent = parent;
            }

            public Event Predict(double currentTime)
            {
                if (_trajectory is EmptyTrajectory) return null;
                var escapeEvent = CalculateEscapeEvent(currentTime);
                var fallEvent = CalculateFallEvent(currentTime);
                return ChooseNearestEvent(escapeEvent, fallEvent);
            }

            private Event CalculateEscapeEvent(double currentTime)
            {
                if (_trajectoryApsis.ReachesAltitude(_parent.GravityRadius))
                {
                    var escapeTime = _trajectory.FindNearestAproachTimeByAttitude(currentTime, _parent.GravityRadius);
                    if (escapeTime > currentTime)
                        return new Event(Event.Types.Escape, escapeTime, _parent);
                }
                return null;
            }

            private Event CalculateFallEvent(double currentTime)
            {
                if (_trajectoryApsis.ReachesAltitude(_parent.SurfaceRadius))
                {
                    var fallTime = _trajectory.FindNearestAproachTimeByAttitude(currentTime, _parent.SurfaceRadius);
                    if (fallTime > currentTime)
                        return new Event(Event.Types.Fall, fallTime, _parent);
                }
                return null;
            }

            private Event ChooseNearestEvent(Event eventA, Event eventB)
            {
                if (eventA == null) return eventB;
                if (eventB == null) return eventA;
                return eventA.Time < eventB.Time ? eventA : eventB;
            }

            /*private Event CalculateJoinEvent(double currentTime, GravitySource neighbour)
            {

            }*/
        }
    }
}