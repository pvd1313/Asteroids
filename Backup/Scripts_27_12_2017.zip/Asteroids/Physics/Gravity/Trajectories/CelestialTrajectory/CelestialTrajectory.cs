﻿namespace Asteroids.Physics.Gravity
{
    public abstract partial class CelestialTrajectory
    {
        public const double GeneralAccuracy = 1e-9;

        public TrajectoryApsis Apsis { get; protected set; }

        protected readonly double CreationTime;

        public CelestialTrajectory(TrajectoryPhysicalProperties trajectoryProperties)
        {
            CreationTime = trajectoryProperties.Body.Time;
        }

        public abstract PlanarVector PositionByTime(double time);
        public abstract PlanarVector VelocityByTime(double time);
        public abstract double FindNearestAproachTimeByAttitude(double currentTime, double targetAttitude);
        public abstract PlanarVector[] CalculateMotionCurve(int topology);
        public abstract PlanarVector[] CalculateMotionCurve(double startTime, double endTime, int topology);
        public abstract PlanarVector Project(PlanarVector position);
        // TODO: RENAME: Find another name, this one not represents the functional.
        public abstract PlanarVector VelocityAtLocalPoint(PlanarVector localPoint, double time);
    }
}