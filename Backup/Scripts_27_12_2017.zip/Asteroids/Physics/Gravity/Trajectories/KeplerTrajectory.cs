﻿using System;

namespace Asteroids.Physics.Gravity
{
    public abstract class KeplerTrajectory : CelestialTrajectory
    {
        protected delegate PlanarVector PositionFromLocalAnomalyFunction(double localAnomaly);

        protected double CreationMeanAnomaly;
        protected double MeanVelocity;
        protected double SemiMajorAxis;
        protected double Mass;

        protected static PlanarVector[] MotionCurveFromAngleRotation(PositionFromLocalAnomalyFunction positionFromLocalAnomalyFunction, double angle, double rotation, int topology)
        {
            var deltaRotation = rotation / topology;
            var curve = new PlanarVector[topology];
            for (var i = 0; i < topology; i++)
                curve[i] = positionFromLocalAnomalyFunction(angle + deltaRotation * (i + 1));
            return curve;
        }

        protected KeplerTrajectory(TrajectoryPhysicalProperties trajectoryProperties) : base(trajectoryProperties)
        {
            Mass = trajectoryProperties.Orbit.Mass;
        }

        protected double MeanAnomalyByTime(double time)
        {
            return CreationMeanAnomaly + (time - CreationTime) * MeanVelocity;
        }

        protected double FindMeanVelocity(double semiMajorAxis, double angularMomentum)
        {
            return Math.Sqrt(Mass / Math.Pow(Math.Abs(semiMajorAxis), 3)) * Math.Sign(angularMomentum);
        }
    }
}