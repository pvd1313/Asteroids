﻿using System;

namespace Asteroids.Physics.Gravity
{
    // TODO: RENAME: Simplify name.
    public struct TrajectoryPhysicalProperties
    {
        public readonly PhysicalBody Body;
        public readonly PhysicalOrbit Orbit;

        public TrajectoryPhysicalProperties(PhysicalBody body, double mass)
        {
            Orbit.Mass = mass;
            Body = body;
            Orbit.AngularMomentum = Body.Position.X * Body.Velocity.Y - Body.Position.Y * Body.Velocity.X;
            var radius = Body.Position.Magnitude;
            var momentumMass = Orbit.AngularMomentum / Orbit.Mass;
            Orbit.Eccentricity.X =  Body.Velocity.Y * momentumMass - Body.Position.X / radius;
            Orbit.Eccentricity.Y = -Body.Velocity.X * momentumMass - Body.Position.Y / radius;
        }

        public static double FindAbsoluteAngularMomentum(double semiMajorAxis, double eccentricity, double mass)
        {
            return Math.Sqrt(mass * semiMajorAxis * (1 - eccentricity * eccentricity));
        }

        public static PlanarVector FindVelocity(PhysicalOrbit orbit, PlanarVector position)
        {
            var radius = position.Magnitude;
            var massMomentum = orbit.Mass / orbit.AngularMomentum;
            PlanarVector velocity;
            velocity.X = -(orbit.Eccentricity.Y + position.Y / radius) * massMomentum;
            velocity.Y =  (orbit.Eccentricity.X + position.X / radius) * massMomentum;
            return velocity;
        }
    }
}