﻿using UnityEngine;
using Abrupt;
using Asteroids.Timing;

namespace Asteroids.Physics.Gravity
{
    public class GravityManager : MonoBehaviour
    {
        private static readonly TimeBasedEventQueue<GravityReceiver.Event> EventQueue;

        static GravityManager()
        {
            SingletonUtil.Create<GravityManager>();
            EventQueue = new TimeBasedEventQueue<GravityReceiver.Event>();
        }

        public static void RegisterEvent(GravityReceiver.Event eventObj)
        {
            EventQueue.AddEvent(eventObj);
        }

        public static void UnregisterEvent(GravityReceiver.Event eventObj)
        {
            EventQueue.RemoveEvent(eventObj);
        }

        private void Update()
        {
            EventQueue.HandleEvents(TimeManager.PreciseTime);
        }
    }
}