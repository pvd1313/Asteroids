﻿namespace Asteroids.Physics.Gravity
{
    public struct TrajectoryApsis
    {
        public PlanarVector Apocenter;
        public PlanarVector Pericenter;

        public TrajectoryApsis(PlanarVector apocenter, PlanarVector pericenter)
        {
            Apocenter = apocenter;
            Pericenter = pericenter;
        }

        public bool ReachesAltitude(double altitude)
        {
            altitude *= altitude;
            if (altitude > Pericenter.SqrMagnitude && altitude < Apocenter.SqrMagnitude)
                return true;
            return false;
        }

        // TODO: IMPLEMENT: ReachesApsis(TrajectoryApsis apsis, double distance)
        /*public bool ReachesApsis(TrajectoryApsis apsis, double distance)
        {
            distance = distance * distance;

            if (PlanarVector.SqrDistance(Apocenter, apsis.Apocenter) < distance) return true;
            if (PlanarVector.SqrDistance(Pericenter, apsis.Pericenter) < distance) return true;

            var apocenterMagDif = Apocenter.SqrMagnitude - apsis.Apocenter.SqrMagnitude;
            var pericenterMagDif = Pericenter.SqrMagnitude - apsis.Pericenter.SqrMagnitude;
            if (apocenterMagDif * pericenterMagDif < 0) return true;
        }*/
    }
}