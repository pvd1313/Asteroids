﻿namespace Asteroids.Physics.Gravity
{
    public struct PhysicalBody
    {
        public PlanarVector Position;
        public PlanarVector Velocity;
        public double Time;

        public PhysicalBody(PlanarVector position, PlanarVector velocity, double time)
        {
            Position = position;
            Velocity = velocity;
            Time = time;
        }
    }
}

