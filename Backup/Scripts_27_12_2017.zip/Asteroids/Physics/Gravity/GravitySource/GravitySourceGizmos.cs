﻿using UnityEngine;

namespace Asteroids.Physics.Gravity
{
    partial class GravitySource
    {
        private void OnDrawGizmos()
        {
            var position = transform.position;
            var up = transform.up;

            Gizmos.color = Color.gray;
            GizmosUtil.DrawCircle(position, up, (float)_data.GravityRadius, 60);
        }
    }
}
