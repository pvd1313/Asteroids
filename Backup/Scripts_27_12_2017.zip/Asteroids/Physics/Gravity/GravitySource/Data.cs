﻿namespace Asteroids.Physics.Gravity
{
    partial class GravitySource
    {
        [System.Serializable]
        private struct Data
        {
            public double Mass;
            public double GravityRadius;
            public double SurfaceRadius;
            public MinMax Gravity
            {
                get
                {
                    var gMin = Mass / (GravityRadius * GravityRadius);
                    var gMax = GravityRadius / SurfaceRadius * gMin;
                    return new MinMax(gMin, gMax);
                }
            }

            public Data(double gravityRadius, MinMax gravity)
            {
                GravityRadius = gravityRadius;
                Mass = gravity.Min * GravityRadius * GravityRadius;
                if (gravity.Max == 0) gravity.Max = 1;
                SurfaceRadius = gravity.Min / gravity.Max * GravityRadius;
            }

            public void Validate()
            {
                if (Mass <= 0) Mass = 1;
                if (SurfaceRadius <= 0) SurfaceRadius = 1;
                if (GravityRadius < SurfaceRadius) GravityRadius = SurfaceRadius;
            }
            
            public static MinMax ValidateGravity(MinMax gravity)
            {
                if (gravity.Min < 0) gravity.Min = 1;
                if (gravity.Max < gravity.Min) gravity.Max = gravity.Min;
                return gravity;
            }
        }
    }
}
