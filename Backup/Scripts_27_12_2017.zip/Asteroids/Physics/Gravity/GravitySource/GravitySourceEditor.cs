﻿#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using Asteroids.EditorExtensions;

namespace Asteroids.Physics.Gravity
{
    partial class GravitySource
    {
        [CustomEditor(typeof(GravitySource))]
        private class GravitySourceEditor : Editor
        {
            public override void OnInspectorGUI()
            {
                var gSource = target as GravitySource;

                var data = DrawData(gSource._data, true);
                gSource._data = data;
                var gravity = DrawGravity(data.Gravity, true);
                if (gravity != data.Gravity)
                    gSource._data = new Data(data.GravityRadius, gravity);
            }

            private Data DrawData(Data data, bool canEdit)
            {
                EditorGUILayoutUtil.HorizontalDisabledTextFields("Surface", "Mass", "Radius");
                EditorGUILayoutUtil.HorizontalDelayedDoubleFields(canEdit, ref data.SurfaceRadius, ref data.Mass, ref data.GravityRadius);
                data.Validate();
                return data;
            }

            private MinMax DrawGravity(MinMax gravity, bool canEdit)
            {
                EditorGUILayoutUtil.HorizontalDisabledTextFields("G Min", "G Max");
                EditorGUILayoutUtil.HorizontalDelayedDoubleFields(canEdit, ref gravity.Min, ref gravity.Max);
                return Data.ValidateGravity(gravity);
            }

            private void OnSceneGUI()
            {
                var gSource = target as GravitySource;
                var gTransform = gSource.transform;
                var gData = gSource._data;
                var doubleSurface = (float)(gData.SurfaceRadius * 2);
                gTransform.localScale = new Vector3(doubleSurface, doubleSurface, doubleSurface);
                Handles.color = new Color(1, 1, 1, .1f);
                Handles.DrawSolidArc(gTransform.position, gTransform.up, gTransform.right, 360, (float)gData.GravityRadius);
            }
        }
    }
}
#endif