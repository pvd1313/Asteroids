﻿using System.Collections.Generic;
using Asteroids.Timing;
using UnityEngine;
using System;

namespace Asteroids.Physics.Gravity
{
    [Serializable]
    public partial class GravitySource : GravityReceiver
    {
        public double Mass { get { return _data.Mass; } }
        public double GravityRadius { get { return _data.GravityRadius; } }
        public double SurfaceRadius { get { return _data.SurfaceRadius; } }

        [SerializeField]
        private Data _data;
        [NonSerialized]
        private List<GravityReceiver> Children = new List<GravityReceiver>();

        // TODO: RENAME: IsWorldPointInsideGravityInfluence 
        // TODO: REFACTORE: Method must depend from time.
        public virtual bool IsWorldPointInside(Vector3 worldPoint)
        {
            var distance = (transform.position - worldPoint).magnitude;
            return distance <= _data.GravityRadius;
        }

        // TODO: REFACTORE: Delete method, it is too simple.
        public virtual bool IsLocalPointInsideSurface(Vector3 localPoint)
        {
            return localPoint.magnitude <= _data.SurfaceRadius;
        }

        public void AddChild(GravityReceiver newChild)
        {
            Children.Add(newChild);
        }

        public void RemoveChild(GravityReceiver child)
        {
            Children.Remove(child);
        }

        /*public virtual Vector2 GetGravity(Vector2 localPoint)
        {
            var distance = Math.Max(localPoint.Magnitude, SurfaceRadius);
            var gravityFactor = -Mass / (distance * distance);
            return localPoint.Normalized * gravityFactor;
        }

        public virtual Vector3 GetStableOrbitVelocity(Vector2 localPoint)
        {
            var velocity = SurfaceOrbitVelocity * Math.Sqrt(SurfaceOrbitRadius / localPoint.magnitude);
            var direction = Vector3.Cross(-localPoint, OrbitUp).normalized;
            return velocity * direction;
        }*/

        public override void ChangeVelocity(PlanarVector deltaVelocity, double atTime)
        {
            throw new Exception("GravitySource velocity can not be changed manually.");
        }

        public CelestialTrajectory CreateTrajectory(PhysicalBody localBody)
        {
            var trajectoryProperties = new TrajectoryPhysicalProperties(localBody, _data.Mass);
            return CreateTrajectory(trajectoryProperties);
        }

        public virtual CelestialTrajectory CreateTrajectory(TrajectoryPhysicalProperties trajectoryProperties)
        {
            if (CircularTrajectory.IsCircular(trajectoryProperties))
                return new CircularTrajectory(trajectoryProperties);
            else if (EllipticTrajectory.IsElliptic(trajectoryProperties))
                return new EllipticTrajectory(trajectoryProperties);
            else if (HyperbolicTrajectory.IsHyperbolic(trajectoryProperties))
                return new HyperbolicTrajectory(trajectoryProperties);
            throw new CoreException("{0}: Unknown orbit token.", GetType().Name);
        }

        /*public void Initialize(GravityField gravityField, PhysicalBody worldBody)
        {
            Children = new List<GravityReceiver>();
            _gravityRadius = gravityField.Radius;
            var gravity = gravityField.Gravity;
            _mass = gravity.Min * _gravityRadius * _gravityRadius;
            _surfaceRadius = gravity.Min / gravity.Max * _gravityRadius;
            base.Initialize(worldBody);
        }

        public override void Initialize(PhysicalBody worldBody)
        {
            throw new CoreException("{0}: Wrong initializer is called.", GetType().Name);
        }*/

        protected virtual void Update()
        {
            foreach (var child in Children)
                child.transform.localPosition = (Vector3) child.WorldPositionByTime(TimeManager.PreciseTime);
        }

        protected override bool CanBeInside(GravitySource target)
        {
            if (GravityRadius * 2 >= target.GravityRadius) return false;
            return base.CanBeInside(target);
        }
    }
}
