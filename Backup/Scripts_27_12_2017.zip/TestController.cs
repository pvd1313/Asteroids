﻿using UnityEngine;
using Asteroids;
using Asteroids.Physics.Gravity;
using Asteroids.Timing;

public class TestController : MonoBehaviour
{
    private static readonly Color BodyColor = new Color(.8f, .8f, .8f, 1f);
    private static readonly Color DirectionColor = new Color(1f, 1f, .3f, 0.5f);

    public float Speed = 5f;

    private GravityReceiver _receiver;
    private Camera _camera;

    protected void Awake()
    {
        _receiver = GetComponent<GravityReceiver>();
        _camera = FindObjectOfType<Camera>();
    }

    protected void Update()
    {
        if (_receiver == null) return;
        Vector3 move;
        if (!GetMovementDirection(transform.position, out move)) return;
        move *= Time.fixedDeltaTime * Speed;
        if (Input.GetKey(KeyCode.LeftShift)) move *= 5;
        _receiver.ChangeVelocity((PlanarVector)move, TimeManager.PreciseTime);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = BodyColor;
        GizmosUtil.DrawCircle(transform.position, Vector3.forward, 8, 5);
        Vector3 dir;
        if (!GetMovementDirection(transform.position, out dir)) return;
        Gizmos.color = DirectionColor;
        GizmosUtil.DrawPlainArrow(transform.position, dir, Vector3.forward, 32);
    }

    private bool GetMovementDirection(Vector3 bodyPosition, out Vector3 direction)
    {
        direction = Vector3.zero;
        if (!Input.GetMouseButton(0)) return false;
        bodyPosition = _camera.WorldToScreenPoint(bodyPosition);
        var mousePosition = Input.mousePosition;
        direction.x = mousePosition.x - bodyPosition.x;
        direction.z = mousePosition.z - bodyPosition.z;
        direction.Normalize();
        return true;
    }
}